package org.example.domain;

import com.github.javafaker.Faker;

import java.util.ArrayList;
import java.util.List;

public class Oficinas extends Instalaciones{
    private int capacEnergetica;


    public int getCapacEnergetica() {
        return capacEnergetica;
    }



    public Oficinas(int IDinst, String loc) {
        super(IDinst, loc);

        Faker faker=new Faker();


        empleados.add(new Empleado(faker.funnyName().name(),1,faker.idNumber().ssnValid(),22,"Asistente administrativo",1341));
        empleados.add(new Empleado(faker.funnyName().name(),2,faker.idNumber().ssnValid(),23,"Contador",4441));
        empleados.add(new Empleado(faker.funnyName().name(),3,faker.idNumber().ssnValid(),44,"Ejecutivo de ventas",1444));
        empleados.add(new Empleado(faker.funnyName().name(),4,faker.idNumber().ssnValid(),122,"Analista de marketing",91230));
        empleados.add(new Empleado(faker.funnyName().name(),5,faker.idNumber().ssnValid(),92,"Especialista en recursos humanos",23425));
        empleados.add(new Empleado(faker.funnyName().name(),6,faker.idNumber().ssnValid(),22,"Asistente administrativo",55234));
        empleados.add(new Empleado(faker.funnyName().name(),7,faker.idNumber().ssnValid(),33,"Contador",33323));
        empleados.add(new Empleado(faker.funnyName().name(),8,faker.idNumber().ssnValid(),41,"Especialista en recursos humanos",23452));
        empleados.add(new Empleado(faker.funnyName().name(),10,faker.idNumber().ssnValid(),22,"Analista de marketing",223));

        departamentos.add(new Departamentos("I+D","Investigar y desarrollar",111));
        departamentos.add(new Departamentos("Administracion","Administrar",112));
        departamentos.add(new Departamentos("RH","Gestión de personal.",113));
        departamentos.add(new Departamentos("Marketing","Publicidad y ventas",114));
    }


    @Override
    public int compareTo(Empleado o) {
        return 0;
    }
}
