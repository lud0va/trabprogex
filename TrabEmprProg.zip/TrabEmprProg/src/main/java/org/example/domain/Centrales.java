package org.example.domain;

import com.github.javafaker.Faker;

public class Centrales extends Instalaciones{
  private int cantEnergGen;

    public Centrales(int IDinst, String loc,int cantEnergGen) {
        super(IDinst, loc);
        this.cantEnergGen=cantEnergGen;

        Faker faker=new Faker();

        empleados.add(new Empleado(faker.funnyName().name(),11,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Ingeniero nuclear",1222));
        empleados.add(new Empleado(faker.funnyName().name(),12,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Técnico de radiación",1234));
        empleados.add(new Empleado(faker.funnyName().name(),13,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Operador de reactor nuclear",444444));
        empleados.add(new Empleado(faker.funnyName().name(),14,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Especialista en seguridad nuclear",3242));
        empleados.add(new Empleado(faker.funnyName().name(),15,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Técnico de mantenimiento",4423));
        empleados.add(new Empleado(faker.funnyName().name(),16,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Especialista en seguridad nuclear",42333));
        empleados.add(new Empleado(faker.funnyName().name(),17,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Operador de reactor nuclear",9999999));
        empleados.add(new Empleado(faker.funnyName().name(),18,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Técnico de radiación",23234));
        empleados.add(new Empleado(faker.funnyName().name(),19,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Ingeniero nuclear",4425));
        empleados.add(new Empleado(faker.funnyName().name(),20,faker.idNumber().ssnValid(),((int)(Math.random()*60)+18),"Técnico de mantenimiento",6343));

        departamentos.add(new Departamentos("I+D","Investigar y desarrollar",115));
        departamentos.add(new Departamentos("Administracion","Administrar",116));
        departamentos.add(new Departamentos("RH","Gestión de personal.",117));
        departamentos.add(new Departamentos("Marketing","Publicidad y ventas",118));
    }


    @Override
    public int compareTo(Empleado o) {
        return 0;
    }
}
