package org.example.domain;



public class Cliente implements Comparable<Cliente>{


    private String nombre;
    private int idCliente;
    private String dni;
    private int edad;
    private String local;

    public Cliente(int idCliente,String nombre,String dni,int edad,  String local) {
        this.dni=dni;
        this.edad=edad;
        this.idCliente=idCliente;
        this.nombre=nombre;
        this.local=local;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    @Override
    public int compareTo(Cliente o) {
        return Integer.compare(this.idCliente,o.idCliente);
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", idCliente=" + idCliente +
                ", dni='" + dni + '\'' +
                ", edad=" + edad +
                ", local='" + local + '\'' +
                '}';
    }
}
