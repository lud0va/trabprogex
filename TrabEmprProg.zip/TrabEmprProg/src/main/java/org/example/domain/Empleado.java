package org.example.domain;

import java.util.Comparator;

public class Empleado implements Comparable<Empleado> , Comparator<Empleado> {

    private String nombre;
    private String dni;
    private int idempleado;
    private int edad;

    private String puesto;
    private int salarioMens;

    public Empleado(String nombre,int idempleado, String dni, int edad, String puesto, int salarioMens) {
        this.nombre = nombre;
        this.idempleado=idempleado;
        this.dni = dni;
        this.edad = edad;

        this.puesto = puesto;
        this.salarioMens = salarioMens;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public int getEdad() {
        return edad;
    }

    public String getPuesto() {
        return puesto;
    }

    public int getSalarioMens() {
        return salarioMens;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "nombre='" + nombre + '\'' +
                ", dni='" + dni + '\'' +
                ", idempleado=" + idempleado +
                ", edad=" + edad +
                ", puesto='" + puesto + '\'' +
                ", salarioMens=" + salarioMens +
                '}'+"\n";
    }

    @Override
    public int compareTo(Empleado o) {
        return Integer.compare(this.idempleado,o.idempleado);
    }

    @Override
    public int compare(Empleado o1, Empleado o2) {
        int aux;

        if (o1.getSalarioMens()>o2.getSalarioMens()){
            aux=1;

        }else if (o2.getSalarioMens()>o1.getSalarioMens()){
            aux=-1;
        }else {
            aux=0;
        }

        return aux;
    }
}
