package org.example.domain;

import java.time.LocalDate;
import java.util.Date;

public class Servicio implements Comparable<Servicio> {
    private int cod_Servicio;
    private String tipoDeServicio;
    private int codCliente;
    private int idInst;
    private LocalDate fechaAlta;

    public Servicio(int cod_Servicio, String tipoDeServicio, int codCliente, int idInst, LocalDate fechaAlta) {
        this.cod_Servicio = cod_Servicio;
        this.tipoDeServicio = tipoDeServicio;
        this.codCliente = codCliente;
        this.idInst = idInst;
        this.fechaAlta = fechaAlta;
    }

    public int getCod_Servicio() {
        return cod_Servicio;
    }

    public void setCod_Servicio(int cod_Servicio) {
        this.cod_Servicio = cod_Servicio;
    }

    public String getTipoDeServicio() {
        return tipoDeServicio;
    }

    public void setTipoDeServicio(String tipoDeServicio) {
        this.tipoDeServicio = tipoDeServicio;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getIdInst() {
        return idInst;
    }

    public void setIdInst(int idInst) {
        this.idInst = idInst;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    @Override
    public int compareTo(Servicio o) {
        return Integer.compare(this.cod_Servicio,o.cod_Servicio);
    }

    @Override
    public String toString() {
        return "Servicio{" +
                "cod_Servicio=" + cod_Servicio +
                ", tipoDeServicio='" + tipoDeServicio + '\'' +
                ", codCliente=" + codCliente +
                ", idInst=" + idInst +
                ", fechaAlta=" + fechaAlta +
                '}'+"\n";
    }
}
