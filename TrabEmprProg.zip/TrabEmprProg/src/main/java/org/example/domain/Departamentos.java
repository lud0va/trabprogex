package org.example.domain;

public class Departamentos {

    private String tipo;
    private String funcion;
    private int idDept;

    public Departamentos(String tipo, String funcion, int idDept) {
        this.tipo = tipo;
        this.funcion = funcion;
        this.idDept = idDept;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFuncion() {
        return funcion;
    }

    public void setFuncion(String funcion) {
        this.funcion = funcion;
    }

    public int getIdDept() {
        return idDept;
    }

    public void setIdDept(int idDept) {
        this.idDept = idDept;
    }

    @Override
    public String toString() {
        return "Departamentos{" +
                "tipo='" + tipo + '\'' +
                ", funcion='" + funcion + '\'' +
                ", idDept=" + idDept +
                '}';
    }
}
