package org.example.domain;


import com.github.javafaker.Faker;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public abstract class Instalaciones implements Comparable<Empleado>{
     protected Set<Empleado> empleados;
     private  int IDinst;
     private String loc;
     protected List<Departamentos> departamentos;
     public Set<Empleado> getEmpleados() {
          return empleados;
     }

     public void setEmpleados(Set<Empleado> empleados) {
          this.empleados = empleados;
     }

     public int getIDinst() {
          return IDinst;
     }

     public void setIDinst(int IDinst) {
          this.IDinst = IDinst;
     }

     public String getLoc() {
          return loc;
     }

     public void setLoc(String loc) {
          this.loc = loc;
     }
     public List<Departamentos> getDepartamentos() {
          return departamentos;
     }
     public Instalaciones(int IDinst, String loc) {

          this.IDinst=IDinst;
          this.loc=loc;
          empleados=new TreeSet<>();
          departamentos=new ArrayList<>();


     }

     @Override
     public String toString() {
          return "\n Instalaciones{" +

                  ", IDinst=" + IDinst +
                  ", loc='" + loc + '\'' +
                  ", departamentos=" + departamentos +
                  '}'+"\n";
     }

}
