package org.example.dao;

import lombok.extern.log4j.Log4j2;
import org.example.common.CompararOficinasPorEnergia;
import org.example.common.ComprobarTipo;
import org.example.common.TipoDeServException;
import org.example.domain.*;

import java.util.*;
import java.util.stream.Collectors;
@Log4j2
public class DaoEmpresaImplementacion implements DaoEmpresa{
   protected Empresa empresa;


    public DaoEmpresaImplementacion(Empresa empresa) {
        this.empresa = empresa;
    }

    public DaoEmpresaImplementacion(){this.empresa=new Empresa();}
    @Override
    public boolean addCliente(Cliente cliente) {

       return empresa.getClientes().add(cliente);
    }

    @Override
    public boolean addInstalaciones(Instalaciones instalaciones) {
     return empresa.getInstalaciones().add(instalaciones);
    }

 @Override
 public boolean addEmpleado(Empleado pa, int id) {
        boolean respuesta = false;
     for (int i = 0; i <empresa.getInstalaciones().size() ; i++) {
         if (id==(empresa.getInstalaciones().get(i).getIDinst())){

             respuesta = empresa.getInstalaciones().get(i).getEmpleados().add(pa);
         }

     }
     return respuesta;
 }



    @Override
    public boolean deleteCliente(int idcliente) {
       boolean respuesta=false;
       Set<Cliente> clientes = empresa.getClientes();
       Set <Cliente> auxClientesEliminar = clientes.stream().filter(c->c.getIdCliente()==idcliente).collect(Collectors.toSet());
       System.out.println(auxClientesEliminar);
       return empresa.getClientes().removeAll(auxClientesEliminar);
    }

    @Override
    public boolean deleteDepart(int idDept) {
     boolean respuesta=false;
     List<Instalaciones> list=empresa.getInstalaciones();
        for (int i = 0; i <list.size() ; i++) {
            for (int j = 0; j < list.get(i).getDepartamentos().size() ; j++) {
                if (list.get(i).getDepartamentos().get(j).getIdDept()==idDept){
                  list.get(i).getDepartamentos().remove(j);
                  empresa.setInstalaciones(list);
                    respuesta=true;
                }

            }

        }

     return respuesta;

    }

    @Override
    public boolean deleteInstalaciones(int idInst) {
        boolean respuesta=false;
      List<Instalaciones> list=empresa.getInstalaciones();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getIDinst()==idInst){


                list.remove(i);
                empresa.setInstalaciones(list);
                respuesta=true;
            }

        }



        return respuesta;
    }

    @Override
    public Set<Servicio> modTipoServices(int codServ,String tiposerv) throws TipoDeServException {
        Set<Servicio> servicios=null;

            ComprobarTipo.tipoOk(tiposerv);
           servicios=empresa.getServicios();
            servicios.stream().filter(z->z.getCod_Servicio()==codServ).forEach(z->z.setTipoDeServicio(tiposerv));








        return servicios;
    }



    @Override
    public Empleado empleadoMaxSalarioInstal(int idinst) {
      Empleado empleadoMax=null;

        for (int i = 0; i <empresa.getInstalaciones().size() ; i++) {

            if (empresa.getInstalaciones().get(i).getIDinst()==idinst){
                Set<Empleado> empleados;
                empleados=empresa.getInstalaciones().get(i).getEmpleados();
               empleadoMax=Collections.max(empleados, Comparator.comparing(Empleado::getSalarioMens));
            }
        }
        return empleadoMax;
    }

    @Override
    public List<Instalaciones> getlistaDeInstPorLoc(String loc) {
        return empresa.getInstalaciones().stream().filter(x->x.getLoc().equals(loc)).toList();
    }

    @Override
    public Set<Cliente> getListaClienteSegunSuTipoDeServicio(String tipoServ) {
           Set<Servicio> serviciosPorTipo  =   empresa.getServicios().stream().filter(x->x.getTipoDeServicio().equals(tipoServ)).collect(Collectors.toSet());
        List<Integer> ids =  serviciosPorTipo.stream().map(Servicio::getCodCliente).toList();
        return empresa.getClientes().stream().filter(x->ids.contains(x.getIdCliente())).collect(Collectors.toSet());
    }

    @Override
    public Set<Empleado> selectListaEmpleadoSegunEdadYPuesto(int edad, String puesto) {


        return empresa.getInstalaciones()
                .stream()
                .map(instalaciones -> instalaciones.getEmpleados())
                .collect(Collectors.toSet())
                .stream()
                .flatMap(Set::stream)
                .filter(x->x.getEdad()==edad && x.getPuesto().equals(puesto))
                .collect(Collectors.toSet());


    }

    @Override
    public List<Instalaciones> listaInstOrder(boolean ascdesc) {
        List<Instalaciones> list=empresa.getInstalaciones();
             if (ascdesc){
                 list.sort(new CompararOficinasPorEnergia()::compare);
           }else {
              list.sort(new CompararOficinasPorEnergia().reversed());
        }

        return list;
    }

    @Override
    public boolean guardar() {
        return empresa.saveClientes();
    }


}
