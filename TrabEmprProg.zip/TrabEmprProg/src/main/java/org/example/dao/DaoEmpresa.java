package org.example.dao;

import org.example.common.TipoDeServException;
import org.example.domain.Cliente;
import org.example.domain.Empleado;
import org.example.domain.Instalaciones;
import org.example.domain.Servicio;

import java.util.List;
import java.util.Set;

public interface DaoEmpresa {



    public boolean addCliente(Cliente cliente);

    public boolean addInstalaciones(Instalaciones instalaciones);

    public boolean addEmpleado(Empleado pa, int id);




    boolean deleteCliente(int dni);



    boolean deleteDepart(int idDept);

   boolean deleteInstalaciones(int idInst);

    public Set<Servicio> modTipoServices(int idServ, String tiposerv) throws TipoDeServException;



    Empleado empleadoMaxSalarioInstal(int idinst);


    List<Instalaciones> getlistaDeInstPorLoc(String loc);

    Set<Cliente> getListaClienteSegunSuTipoDeServicio(String  s);

    Set<Empleado> selectListaEmpleadoSegunEdadYPuesto(int edad, String puesto);

    List<Instalaciones>  listaInstOrder(boolean ascdesc);
     boolean guardar();
}
