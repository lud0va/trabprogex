package org.example.dao;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import lombok.extern.log4j.Log4j2;
import org.example.Configuracion.Configuracion;
import org.example.domain.*;
import com.github.javafaker.Faker;

import javax.security.auth.login.Configuration;
import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
@Log4j2
public class Empresa {
private List<Instalaciones> instalaciones;
private Set<Cliente> clientes;
private Set<Servicio> servicios;

    public Empresa() {
        instalaciones=new ArrayList<>();
        clientes=new HashSet<>();
        servicios=new TreeSet<>();
        Faker faker=new Faker();
        //instalaciones
        //oficinas
        instalaciones.add(new Oficinas(114,"Nueva York"));
        instalaciones.add(new Oficinas(111,"Tokio"));
        instalaciones.add(new Oficinas(113,"Londres"));
        instalaciones.add(new Oficinas(112,"París"));
        instalaciones.add(new Oficinas(115,"Roma"));
        //instalaciones
        //centrales
        instalaciones.add(new Centrales(003,"Nueva York",20000));
        instalaciones.add(new Centrales(001,"Tokio",20000));
        instalaciones.add(new Centrales(002,"Ciudad del Cabo",20000));
        instalaciones.add(new Centrales(005,"Moscú",20000));
        instalaciones.add(new Centrales(006,"Toronto",20000));
        instalaciones.add(new Centrales(004,"Ciudad de México",20000));
        //Servicios
        servicios.add(new Servicio(993,"Privado",300,111,LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(994,"Publico",301,113,LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(995,"Privado",302,115, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(996,"Publico",303,002, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(997,"Privado",304,004, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(998,"Publico",305,006, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        //Clientes
        /*clientes.add(new Cliente(300,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"Ciudad de México"));
        clientes.add(new Cliente(301,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"Buenos Aires"));
        clientes.add(new Cliente(302,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"Estambul"));
        clientes.add(new Cliente(303,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"El Cairo"));
        clientes.add(new Cliente(304,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"Bangkok"));
        clientes.add(new Cliente(305,faker.pokemon().name(),faker.code().ean8(),((int)(Math.random()*80)+18),"Pekín"));*/

        cargarClientes();
    }
   /* public Empresa(){


    }*/
    public  Set<Cliente> cargarClientes(){
        Gson gson=new Gson();
        Type userListType = new TypeToken<HashSet<Cliente>>() {}.getType();
        clientes=null;

        try {
            clientes=gson.fromJson(
                    new FileReader(new Configuracion().LoadPathProperties()),userListType);

        }catch (FileNotFoundException e){
                 log.error(e.getMessage(),e);


        }



        return  clientes;
    }
    public  boolean saveClientes(){
        Gson gson=new GsonBuilder().setPrettyPrinting().create();
        System.out.println(clientes);
        try (FileWriter fw=new FileWriter(new Configuracion().LoadPathProperties())){

            gson.toJson(clientes, fw);


        }catch (IOException e){
          log.error(e.getMessage(),e);
        return false;
        }
        return true;
    }

    public List<Instalaciones> getInstalaciones() {
        return instalaciones;
    }

    public Set<Cliente> getClientes() {
        return clientes;
    }

    public Set<Servicio> getServicios() {
        return servicios;
    }

    public void setInstalaciones(List<Instalaciones> instalaciones) {
        this.instalaciones = instalaciones;
    }

    public void setClientes(Set<Cliente> clientes) {
        this.clientes = clientes;
    }

    public void setServicios(Set<Servicio> servicios) {
        this.servicios = servicios;
    }


}
