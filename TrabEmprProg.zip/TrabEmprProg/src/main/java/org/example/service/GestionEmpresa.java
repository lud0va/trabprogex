package org.example.service;

import org.example.common.TipoDeServException;
import org.example.dao.DaoEmpresa;
import org.example.dao.DaoEmpresaImplementacion;
import org.example.domain.Cliente;
import org.example.domain.Empleado;
import org.example.domain.Instalaciones;
import org.example.domain.Servicio;

import java.util.List;
import java.util.Set;

public class GestionEmpresa implements IGestionEmpresa {
    private final DaoEmpresa daoEmpresa;


    public GestionEmpresa(DaoEmpresa daoEmpresa) {
        this.daoEmpresa = daoEmpresa;
    }

    public GestionEmpresa() {
        this.daoEmpresa=new DaoEmpresaImplementacion();
    }


    @Override
    public boolean addCliente(Cliente cliente) {
       return daoEmpresa.addCliente(cliente);
    }

    @Override
    public boolean addInstalaciones(Instalaciones instalaciones) {
       return daoEmpresa.addInstalaciones(instalaciones);
    }

    @Override
    public boolean addEmpleado(Empleado pa, int id) {
       return daoEmpresa.addEmpleado(pa,id);
    }

    @Override
    public boolean deleteCliente(int dni) {
        return daoEmpresa.deleteCliente(dni);
    }

    @Override
    public boolean deleteDepart(int idDept) {
        return daoEmpresa.deleteDepart(idDept);
    }

    @Override
    public boolean deleteInstalaciones(int idInst) {
        return daoEmpresa.deleteInstalaciones(idInst);
    }

    @Override
    public Set<Servicio> modServices(int cod, String tiposerv) throws TipoDeServException {
       return daoEmpresa.modTipoServices(cod,tiposerv);
    }


    @Override
    public Empleado empleadoMaxSalarioInstal(int idinst) {
        return daoEmpresa.empleadoMaxSalarioInstal(idinst);
    }

    @Override
    public List<Instalaciones> getlistaDeInstPorLoc(String loc) {
        return daoEmpresa.getlistaDeInstPorLoc(loc);
    }

    @Override
    public Set<Cliente> getListaClienteSegunSuTipoDeServicio(String s) {
        return  daoEmpresa.getListaClienteSegunSuTipoDeServicio(s);
    }

    @Override
    public Set<Empleado> selectListaEmpleadoSegunEdadYPuesto(int edad, String puesto) {
        return daoEmpresa.selectListaEmpleadoSegunEdadYPuesto(edad,puesto);
    }

    @Override
    public List<Instalaciones>  listaInstOrder(boolean ascdesc) {
        return daoEmpresa. listaInstOrder(ascdesc);
    }

    @Override
    public boolean guardar() {
        return daoEmpresa.guardar();
    }
}
