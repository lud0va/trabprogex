package org.example.common;

import org.example.domain.Empleado;
import org.example.domain.Instalaciones;

import java.util.Comparator;

public class CompararOficinasPorEnergia implements Comparator<Instalaciones> {


    @Override
    public int compare(Instalaciones o1, Instalaciones o2) {

        int aux=Integer.compare(o1.getIDinst(), o2.getIDinst());
        return aux;
    }

    @Override
    public Comparator<Instalaciones> reversed() {
        return Comparator.super.reversed();
    }
}
