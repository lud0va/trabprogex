package org.example.common;

public class Constantes {
    public static final String PASSWDADMN="123";

    public static final String PASSWDS="912";
    public static final String PASSWD="Introduzca la contraseña de administrador o de usuario";

    public static final String PASSWDERROR="Contraseña invalida";
    public static final String ERRCAT="El tipo de servicio tiene que ser publico o privado";

    public static final String INTRO="Introduzca :";

    public static final String SERADMIN="Entrar como administrador";

    public static final String SERUSER="Entrar como usuario";

    public static final String OPCIONADMN1="Añadir cliente";
    public static final String OPCIONADMN2="Añadir instalaciones";
    public static final String OPCIONADMN3="Añadir empleados";
    public static final String OPCIONADMN4="Borrar cliente";
    public static final String OPCIONADMN5="Borrar departamento";
    public static final String OPCIONADMN6="Borrar instalaciones";
    public static final String OPCIONADMN7="Modificar el tipo del un servicio";
    public static final String OPCIONADMN8="Mostrar el empleado con mayor salario";
    public static final String OPCIONADMN9="Mostrar la lista de instalaciones segun su localidad";
    public static final String OPCIONADMN10="Mostrar lista de clientes según el tipo de servicio solicitado";
    public static final String OPCIONADMN11="Lista de empleados según edad y puesto";

    public static final String INTRONOMBCLIENTE="Introduzca nombre del cliente";

    public static final String INTROIDCLIENTE="Introduzca el id del cliente";

    public static final String INTROEDADCLIENTE="Introduzca la edad del cliente";

    public static final String INTRODNICLIENTE="Introduzca el dni del cliente";

    public static final String INTRODLOCCLIENTE="Introduzca la localización del cliente";

    public static final String CLIENTEADDED="Cliente añadido";

    public static final  String CLIENTEINVALIDO="Cliente invalido";

    public static final String OFICINA="Si quiere añadir una oficina";

    public static final String CENTRAL="Si quiere añadir una central";

    public static final String INTROIDINSTI="Introduzca la id de la instalación";

    public static final String INTROLOCALINST="Introduzca la localización de la instalacion";

    public static final String INTROCANTENERG="Introduzca la cantidad de energia de la central";

    public static final String OPCINV="La opcion es invalida";

    public static final String INSTALACIONAÑADID="Instalacion añadida";

    public static final String ADDNOMBEMPLEADO="Introduzca el nombre del empleado";

    public static final String ADDIDEMPLEADO="Introduzca el id del empleado";

    public static final String ADDDNIEMPLEADO="Introduzca el dni del empleado";

    public static final String ADDPUESTOEMPLEADO="Introduzca el puesto del empleado";

    public static final String ADDEDADEMPLEADO="Introduzca la edad del empleado";

    public static final String ADDSALARIOEMPLEADO="Introduzca el salario del empleado";

    public static final String INSTALACIONINV="Instalación invalida";

    public static final String INTROIDINST="Introduzca el id de la instalación a la que pertenezca";

    public static final String ERRORADD="Error: alguno de los elementos invalido";

    public static final String ELEMAÑADIDOEX="Elemento añadido con exito";

    public static final String ADDIDDEPT="Añade la id del departamento";

    public static final String ERRORDEL="Error: no se ha podido eliminar el elemento";

    public static final String DELETELEM="Elemento eliminado con exito";

    public static final String ADDIDINST="Añade la id de la instalación";

    public  static final String ADDIDCLIENTE="Añade la id del cliente";

    public static final String ADDIDSERV="Añade la id del servicio";

    public static final String ADDTIPOSERV="Añade el tipo de servicio";

    public static final String SERVMODIFICADO="Servicio modificado";

    public static final String SERVERROR="El servicio no ha podido ser modificiado";

    public static final String EMPMAX="El empleado con mayor salario es: ";

    public static final String INTROIDINSTEMPMAXSAL="Introduzca el id de la institución de la cual quiera sacar el empleado de mayor salario";

    public static final String INTRODUCALALOC="Introduzca la localidad por la que quiera filtrar";

    public static final String INSTPORLOC="Instalaciones segun la localidad";

    public static final String CLIENTESSEGUNTIPSERV="Los clientes segun el tipo de servicio";

    public static final String EMPLEADOSSEGUNEDYPUEST="Los empleados segun la edad y el puesto son: ";

    public static final String OPCIOONINV="Opción invalida";

    public static final String SALIRMENU="Salir del menu";

    public static final String OPCIONADMN12="Ordenar empleados por salario";

    public static final String ORDENARLISTDESC="Ordenar empleados descendentemente";

    public static final String ORDENARLISTDASC="Ordenar empleados asc";

    public static final String DNINOVALIDO="Dni no valido";

    public static final String GETLIST="Mostrar lista de instalaciones, clientes o servicios";

    public static final String GETLISTX="Introduzca \n 1: Si quiere la lista de las instalaciones \n 2: si quiere la lista de los servicios \n 3: si quiere la lista de clientes";

}
