package org.example.common;

public class TipoDeServException extends Exception {

    public TipoDeServException(){super(Constantes.ERRCAT);}

}
