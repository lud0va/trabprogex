package org.example.common;

public class ComprobarTipo {
    public static void tipoOk(String tipo) throws TipoDeServException{
        if (tipo.equals("Publico") ==false && tipo.equals("Privado")==false){
            throw new TipoDeServException();
        }
    }
}
