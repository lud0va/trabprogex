package org.example;

import org.example.ui.GestionMenu;

public class Main {
    public static void main(String[] args) {
      GestionMenu.menu();



    }
}