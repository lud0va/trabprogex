package org.example.ui;

import lombok.extern.log4j.Log4j2;
import org.example.common.Constantes;
import org.example.common.TipoDeServException;
import org.example.domain.*;
import org.example.service.GestionEmpresa;
import org.example.service.IGestionEmpresa;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Log4j2
public class GestionAdmin {
    private GestionEmpresa ge=new GestionEmpresa();

    public GestionAdmin(GestionEmpresa ge) {
        ge=this.ge;
    }

    public void menu(){
        Scanner nscanner=new Scanner(System.in);
        String cleaner;
        boolean flag=false;
        while (flag==false){
        System.out.println(Constantes.INTRO+"\n 1 "+Constantes.OPCIONADMN1+"\n 2 "+Constantes.OPCIONADMN2+"\n 3 "+Constantes.OPCIONADMN3+"\n 4 "+Constantes.OPCIONADMN4+"\n 5 "+Constantes.OPCIONADMN5+"\n 6 "+Constantes.OPCIONADMN6+"\n 7 "+Constantes.OPCIONADMN7+"\n 8 "+Constantes.OPCIONADMN8+"\n 9 "+Constantes.OPCIONADMN9+"\n 10 "+Constantes.OPCIONADMN10+"\n 11 "+Constantes.OPCIONADMN11+"\n 12"+Constantes.OPCIONADMN12+"\n 0 "+Constantes.SALIRMENU);
        int opt=nscanner.nextInt();
        switch (opt) {

            case 1:

                boolean si=añadirCliente();
                 if (si==true){
                     System.out.println(Constantes.CLIENTEADDED);
                 }else {
                     System.out.println(Constantes.CLIENTEINVALIDO);
                 }

                break;


            case 2:
                      if (añadirInstalacion()){
                          System.out.println(Constantes.INSTALACIONAÑADID);
                      }else{
                          System.out.println(Constantes.INSTALACIONINV);
                      }


                break;

            case 3:
                if (añadirEmpleado()){
                    System.out.println(Constantes.ELEMAÑADIDOEX);
                }else {
                    System.out.println(Constantes.ERRORADD);

                }

                break;


            case 4:

                if (eliminarCliente()){
                    System.out.println(Constantes.DELETELEM);
                }else {
                    System.out.println(Constantes.ERRORDEL);
                }
                break;

            case 5:
                if (eliminarDepart()){
                    System.out.println(Constantes.DELETELEM);
                }else {
                    System.out.println(Constantes.ERRORDEL);
                }

                break;

            case 6:
                if (eliminarInstalacion()){
                    System.out.println(Constantes.DELETELEM);
                }else {
                    System.out.println(Constantes.ERRORDEL);
                }
                break;

            case 7:

                System.out.println(Constantes.ADDIDSERV);
                int idserv=nscanner.nextInt();
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.ADDTIPOSERV);
                String tiposerv=nscanner.nextLine();


          try {
              modServicios(idserv, tiposerv).contains(tiposerv);
              log.info(Constantes.SERVMODIFICADO);
          } catch (TipoDeServException e) {
             log.error(e.getMessage());
             log.info( Constantes.SERVERROR);
          }



                break;

            case 8:
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.INTROIDINSTEMPMAXSAL);
                int idinst= nscanner.nextInt();
                System.out.println(Constantes.EMPMAX+empleadoMax(idinst));

                break;

            case 9:
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.INTROLOCALINST);
                String local=nscanner.nextLine();
                log.info(Constantes.INSTPORLOC+instalacionesPorLoc(local));


                break;


            case 10:
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.ADDTIPOSERV);
                String tiposervic=nscanner.nextLine();
              log.info(Constantes.CLIENTESSEGUNTIPSERV+listaDeClientesSegunServ(tiposervic));

                break;

            case 11:
                System.out.println(Constantes.ADDEDADEMPLEADO);
                int edad=nscanner.nextInt();
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.ADDPUESTOEMPLEADO);
                String puesto=nscanner.nextLine();
                log.info(Constantes.EMPLEADOSSEGUNEDYPUEST+empleadoEdadyPuesto(edad,puesto));

                break;

            case 12:

                boolean descasc=false;
                System.out.println(Constantes.INTRO+"\n 1"+Constantes.ORDENARLISTDASC+"\n 2"+Constantes.ORDENARLISTDESC);
                int op=nscanner.nextInt();
                if (op==1){
                    descasc=true;
                    ge. listaInstOrder(descasc);

                }else if (op==2){
                    descasc=false;

                }else {
                    log.error(Constantes.OPCINV);
                    break;
                }
                List<Instalaciones> ordenado= ge. listaInstOrder(descasc);
                System.out.println(ordenado);
                break;
            case 0:
                ge.guardar();
                flag=true;
                break;

            default:

                log.error(Constantes.OPCINV);
                break;
        }

        }














    }
    public void OrdenarEmpleados(){






    }

    public boolean añadirCliente(){
    Scanner nscanner=new Scanner(System.in);
    boolean respueta=false;
    String cleaner;
        System.out.println(Constantes.INTROIDCLIENTE);
        int idcliente=nscanner.nextInt();
        cleaner=nscanner.nextLine();
        System.out.println(Constantes.INTRONOMBCLIENTE);
        String nombre=nscanner.nextLine();
        System.out.println(Constantes.INTROEDADCLIENTE);
        int edad=nscanner.nextInt();
        cleaner=nscanner.nextLine();
        System.out.println(Constantes.INTRODNICLIENTE);
        String dni=nscanner.nextLine();
        Pattern pat = Pattern.compile("[0-9]{7}[A-Z]{1}");
        Matcher mat = pat.matcher(dni);
        if (mat.find()) {
            System.out.println(Constantes.INTRODLOCCLIENTE);
            String loc=nscanner.nextLine();


            Cliente cliente=new Cliente(idcliente,nombre,dni,edad,loc);
            respueta=  ge.addCliente(cliente);

        } else {
            System.out.println(Constantes.DNINOVALIDO);
        }


  return respueta;
    }

    public boolean añadirInstalacion(){
        Scanner nscanner=new Scanner(System.in);
        int idInst;
        String loc;
        String cleaner;
        boolean resp=false;
        System.out.println(Constantes.INTRO+"\n 1"+Constantes.OFICINA+"\n 2"+Constantes.CENTRAL);
        int option= nscanner.nextInt();
        switch (option){

            case 1:
                System.out.println(Constantes.INTROIDINSTI);
                idInst=nscanner.nextInt();
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.INTROLOCALINST);
                loc=nscanner.nextLine();
                Instalaciones inst=new Oficinas(idInst,loc);

             resp=  ge.addInstalaciones(inst);

                break;

            case 2:
                System.out.println(Constantes.INTROIDINSTI);
                idInst=nscanner.nextInt();
                cleaner=nscanner.nextLine();
                System.out.println(Constantes.INTROLOCALINST);
                loc=nscanner.nextLine();
                System.out.println(Constantes.INTROCANTENERG);
                int canten=nscanner.nextInt();
                Instalaciones central=new Centrales(idInst,loc,canten);
               resp= ge.addInstalaciones(central);

                break;

            default:
                System.out.println(Constantes.OPCINV);
                resp=false;
                break;


        }




    return resp;
    }


    public boolean añadirEmpleado(){

        Scanner nscanner=new Scanner(System.in);
     boolean respuesta=false;
        String cleaner;
        boolean resp=false;
        System.out.println(Constantes.ADDNOMBEMPLEADO);
        String nombre=nscanner.nextLine();
        System.out.println(Constantes.ADDIDEMPLEADO);
        int idempleado=nscanner.nextInt();
        cleaner=nscanner.nextLine();
        System.out.println(Constantes.ADDDNIEMPLEADO);
        String dni=nscanner.nextLine();
        System.out.println(Constantes.ADDEDADEMPLEADO);
        int edad=nscanner.nextInt();
        cleaner=nscanner.nextLine();
        System.out.println(Constantes.ADDPUESTOEMPLEADO);
        String puesto=nscanner.nextLine();
        System.out.println(Constantes.ADDSALARIOEMPLEADO);
        int salario=nscanner.nextInt();
        cleaner=nscanner.nextLine();
        Empleado empleado=new Empleado(nombre,idempleado,dni,edad,puesto,salario);
        System.out.println(Constantes.INTROIDINST);
        int idist=nscanner.nextInt();
        cleaner=nscanner.nextLine();
   respuesta=     ge.addEmpleado(empleado,idist);

        return respuesta;
    }

    public boolean eliminarDepart(){
        Scanner scanner=new Scanner(System.in);
        boolean respuesta=false;
        System.out.println(Constantes.ADDIDDEPT);
        int idempt=scanner.nextInt();
   respuesta=     ge.deleteDepart(idempt);

    return respuesta;
    }

    public boolean eliminarInstalacion(){
        Scanner ns=new Scanner(System.in);
        boolean resp=false;
        System.out.println(Constantes.ADDIDINST);
        int idinst=ns.nextInt();
    resp=  ge.deleteInstalaciones(idinst);

        return resp;
    }

    public boolean eliminarCliente(){
        Scanner  nsc=new Scanner(System.in);
        boolean resp=false;
        System.out.println(Constantes.ADDIDCLIENTE);
        int idclietne=nsc.nextInt();
     resp=   ge.deleteCliente(idclietne);


        return resp;
    }

    public  Set<Servicio> modServicios(int idserv, String tiposerv) throws TipoDeServException {
        Scanner nscanner=new Scanner(System.in);
        Set<Servicio> servicios=new HashSet<>();

        servicios= ge.modServices(idserv,tiposerv);


        return servicios;
    }
    public Empleado empleadoMax(int ideInst){
        Empleado empleado=ge.empleadoMaxSalarioInstal(ideInst);
        return empleado;

    }

    public List<Instalaciones> instalacionesPorLoc(String loc){
       List<Instalaciones> instalaciones=ge.getlistaDeInstPorLoc(loc);
      return instalaciones;


    }

    public Set<Cliente> listaDeClientesSegunServ(String tiposerv){
        Set<Cliente> clientes=ge.getListaClienteSegunSuTipoDeServicio(tiposerv);
        return clientes;


    }
    public Set<Empleado> empleadoEdadyPuesto(int edad,String puesto){
        Scanner nscan=new Scanner(System.in);

        Set <Empleado> empleado=ge.selectListaEmpleadoSegunEdadYPuesto(edad,puesto);
        return empleado;


    }

}
