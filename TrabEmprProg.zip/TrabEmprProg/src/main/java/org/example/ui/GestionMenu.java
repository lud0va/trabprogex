package org.example.ui;

import lombok.extern.log4j.Log4j2;
import org.example.common.Constantes;
import org.example.service.GestionEmpresa;

import java.util.InputMismatchException;
import java.util.Scanner;
@Log4j2
public class GestionMenu {
    public GestionMenu() {
    }

    public static final void menu(){
        GestionEmpresa ge=new GestionEmpresa();
        Scanner nscann=new Scanner(System.in);
        String cleaner;
        String passwd=null;
        boolean flag=false;
        try {


        while(flag==false) {
            System.out.println(Constantes.INTRO + "\n 1 " + Constantes.SERADMIN + "\n 2 " + Constantes.SERUSER);
            int option = nscann.nextInt();
            switch (option) {
                case 1:
                    cleaner = nscann.nextLine();
                    System.out.println(Constantes.PASSWD);
                    passwd = nscann.nextLine();
                    if (passwd.equals(Constantes.PASSWDADMN) == false) {
                        System.out.println(Constantes.PASSWDERROR);

                    } else {

                        GestionAdmin ga = new GestionAdmin(ge);
                        ga.menu();
                        flag=true;

                    }

                    break;


                case 2:
                    cleaner = nscann.nextLine();
                    System.out.println(Constantes.PASSWD);
                    passwd = nscann.nextLine();
                    if (passwd.equals(Constantes.PASSWDS) == false) {
                        System.out.println(Constantes.PASSWDERROR);

                    } else {
                        GestionUser gu = new GestionUser(ge);
                        gu.menu();
                        flag=true;

                    }


                    break;


                default:
                       log.error(Constantes.OPCIOONINV);
                    break;
            }


        }













        }catch (InputMismatchException e){
            System.out.println(Constantes.OPCINV);
        }
















    }






}
