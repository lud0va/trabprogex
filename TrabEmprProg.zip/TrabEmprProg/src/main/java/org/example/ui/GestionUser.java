package org.example.ui;

import org.example.common.Constantes;
import org.example.domain.Cliente;
import org.example.domain.Empleado;
import org.example.domain.Instalaciones;
import org.example.service.GestionEmpresa;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class GestionUser {

    private GestionEmpresa ge=new GestionEmpresa();

    public GestionUser(GestionEmpresa ge) {
        this.ge = ge;
    }

    public void menu(){
        Scanner nscanner=new Scanner(System.in);
String cleaner;
        boolean flag=false;
        while (flag==false){
            System.out.println(Constantes.INTRO+"\n 1 "+Constantes.OPCIONADMN9+"\n 2 "+Constantes.OPCIONADMN10+"\n 3 "+Constantes.OPCIONADMN11+"\n 0 "+Constantes.SALIRMENU);
            int opt=nscanner.nextInt();
            switch (opt) {

                case 1:
                    cleaner=nscanner.nextLine();
                    System.out.println(Constantes.INTROLOCALINST);
                    String local=nscanner.nextLine();
                    System.out.println(Constantes.INSTPORLOC+"\n "+instalacionesPorLoc(local));


                    break;



                case 2:
                    cleaner= nscanner.nextLine();
                    System.out.println(Constantes.ADDTIPOSERV);
                    String tiposervic=nscanner.nextLine();
                    System.out.println(Constantes.CLIENTESSEGUNTIPSERV+listaDeClientesSegunServ(tiposervic));

                    break;

                case 3:
                    cleaner= nscanner.nextLine();
                    System.out.println(Constantes.ADDEDADEMPLEADO);
                    int edad=nscanner.nextInt();
                    cleaner= nscanner.nextLine();
                    System.out.println(Constantes.ADDPUESTOEMPLEADO);
                    String puesto=nscanner.nextLine();
                    System.out.println(Constantes.EMPLEADOSSEGUNEDYPUEST+empleadoEdadyPuesto(edad,puesto));

                    break;
                case  0:
                    ge.guardar();
                    flag=true;
                    break;

                default:
                    System.out.println(Constantes.OPCINV);
                    break;
            }

        }














    }
    public List<Instalaciones> instalacionesPorLoc(String loc){
        List<Instalaciones> instalaciones=ge.getlistaDeInstPorLoc(loc);
        return instalaciones;


    }

    public Set<Cliente> listaDeClientesSegunServ(String tiposerv){
        Set<Cliente> clientes=ge.getListaClienteSegunSuTipoDeServicio(tiposerv);
        return clientes;


    }
    public Set<Empleado> empleadoEdadyPuesto(int edad, String puesto){
        Scanner nscan=new Scanner(System.in);

        Set <Empleado> empleado=ge.selectListaEmpleadoSegunEdadYPuesto(edad,puesto);
        return empleado;


    }

}
