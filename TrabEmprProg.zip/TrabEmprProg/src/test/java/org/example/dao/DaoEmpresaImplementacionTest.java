package org.example.dao;

import lombok.extern.log4j.Log4j2;
import org.example.common.ComprobarTipo;
import org.example.common.TipoDeServException;
import org.example.domain.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.InstanceOfAssertFactories.list;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
@Log4j2
@ExtendWith(MockitoExtension.class)
class DaoEmpresaImplementacionTest {
    @InjectMocks DaoEmpresaImplementacion daoEmpresaImpl;
    @Mock Empresa empresa;

    @BeforeEach
    void inicioCadaTest() {
        System.out.println("----Comienzo Test");
    }

    @AfterEach
    public void despuesCadaTest() {
        System.out.println("----Termina Test");
    }
  @Nested
  class Add{
    @Test
    void addClienteNull() {
        //given
        Cliente cliente=new Cliente(231,"Dio","9193910D",999,"El Cairo");
        //when
        when(empresa.getClientes()).thenReturn(new HashSet<>());
        boolean flag=daoEmpresaImpl.addCliente(cliente);
        //then
        assertThat(flag).isEqualTo(true);
        if (flag){

            System.out.println("Prueba completada con exito");
        }else {
            System.out.println("La prueba ha fallado con exito");
        }
    }
    @Test
    void addClienteNotNull(){
        //given
        Cliente cliente=new Cliente(231,"Dio","9193910D",999,"El Cairo");
        Set<Cliente> clientes = new HashSet<>();
        clientes.add(new Cliente(122, "Antonio", "1231234M", 22, "Murcia"));
        clientes.add(new Cliente(132, "pepe", "7296353H", 82, "Almuñecar"));
        //when
        when(empresa.getClientes()).thenReturn(clientes);
        boolean flag=daoEmpresaImpl.addCliente(cliente);
        //then
        assertThat(flag).isEqualTo(true);
       if (flag){

           log.info("\"La prueba ha fallado con exito\"");
       }else {
         log.error("La prueba ha fallado con exito");
       }
    }
    @Test
       void addEmplaedo(){
        //given
        Empleado empleado=new Empleado("Abdul",321,"11231Ñ",23,"Limpia cristales",1500);
       List<Instalaciones> inst=new ArrayList<Instalaciones>();
        inst.add(new Oficinas(1231,"Cuba"));
        inst.add(new Centrales(2131,"Segovia",12231));
        //when
        when(empresa.getInstalaciones()).thenReturn(inst);
      boolean respuesta=  daoEmpresaImpl.addEmpleado(empleado,1231);
        //then
        assertThat(respuesta).isEqualTo(true);

    }

   }
@Nested
class eliminar{
    @Test
    void deleteDepart() {
      //given
        List<Instalaciones> inst=new ArrayList<>();
        inst.add(new Oficinas(1231,"Cuba"));
        inst.add(new Centrales(2131,"Segovia",12231));
        //when
        when(empresa.getInstalaciones()).thenReturn(inst);
        //los departamentos se crean automaticamente a la hora de crear unas oficinas o unas centrales, y todas tienen los mismos cuatro departamentos y sus codigos
        boolean respuesta=daoEmpresaImpl.deleteDepart(112);
        //then
        assertThat(respuesta).isEqualTo(true);
    }

    @Test
    void deleteInstalaciones() {
        //given
        List<Instalaciones> inst=new ArrayList<>();
        inst.add(new Oficinas(1231,"Colombia"));
        inst.add(new Centrales(2131,"Almuñecar",12231));
        //when
        when(empresa.getInstalaciones()).thenReturn(inst);
        boolean respuesta=daoEmpresaImpl.deleteInstalaciones(2131);
        //then
        assertThat(respuesta).isEqualTo(true);
    }
    @Test
    void delCliente() {
        //given

        Set<Cliente> clientes = new HashSet<>();
        clientes.add(new Cliente(122, "Antonio", "1231234M", 22, "Murcia"));
        clientes.add(new Cliente(132, "pepe", "7296353H", 82, "Almuñecar"));

        //when
        when(empresa.getClientes()).thenReturn(clientes);
        boolean flag=daoEmpresaImpl.deleteCliente(122);
        //then
        assertThat(flag).isEqualTo(true);
    }
}
    @ParameterizedTest
    @ValueSource(strings = {"Publico","Privado","SI"})
    void modServices(String tipo) {
      //given
        Set<Servicio> servicios=new TreeSet<>();
        servicios.add(new Servicio(123,"Publico",300,111, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(143,"Privado",300,111, LocalDate.of((int) (Math.random() * 20) + 2000, (int) (Math.random() * 12) + 1, (int) (Math.random() * 28) + 1)));
     //when
     when(empresa.getServicios()).thenReturn(servicios);
        try {
            daoEmpresaImpl.modTipoServices(123,tipo);
        } catch (TipoDeServException e) {
            log.error(e.getMessage());
        }

        //then
           assertAll(
                   ()->assertThat(servicios.stream().filter(x->x.getCod_Servicio()==123).findFirst().get().getTipoDeServicio()).isEqualTo(tipo)
           );



    }

    @Nested
    class parametrizados{
        @ParameterizedTest
        @ValueSource(strings = {"Madrid","Almuñecar","Cordoba"})

        void getlistaDeInstPorLoc(String loc) {
            //given
            List<Instalaciones> list=new ArrayList<>();
            list.add(new Oficinas(3123,"Cordoba"));
            list.add(new Centrales(1312,"Almuñecar",333123));
            list.add(new Oficinas(1231,"Madrid"));
            list.add(new Oficinas(31343,"Cordoba"));
            list.add(new Centrales(1322,"Almuñecar",333123));
            list.add(new Oficinas(151,"Madrid"));

            //when
            when(empresa.getInstalaciones()).thenReturn(list);
           List<Instalaciones> listaLoc=daoEmpresaImpl.getlistaDeInstPorLoc(loc);
            //then
            assertAll(
                    ()->assertThat(listaLoc.stream().filter(x->x.getLoc().equals(loc)))
            );

        }
        @ParameterizedTest
        @ValueSource(strings = {"Privado","Publico","Publico"})
        void getListaClienteSegunSuTipoDeServicio(String tipo) {
            //given
            Set<Servicio> servicios=new TreeSet<>();
            servicios.add(new Servicio(123,"Publico",113,111, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
            servicios.add(new Servicio(153,"Privado",121,111, LocalDate.of((int) (Math.random() * 20) + 2000, (int) (Math.random() * 12) + 1, (int) (Math.random() * 28) + 1)));
            servicios.add(new Servicio(423,"Publico",113,111, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
            servicios.add(new Servicio(553,"Privado",121,111, LocalDate.of((int) (Math.random() * 20) + 2000, (int) (Math.random() * 12) + 1, (int) (Math.random() * 28) + 1)));
            Set<Cliente> clientes = new HashSet<>();
            clientes.add(new Cliente(113, "Antonio", "1231234M", 22, "Murcia"));
            clientes.add(new Cliente(121, "pepe", "7296353H", 82, "Almuñecar"));
            clientes.add(new Cliente(113, "fus", "126134P", 22, "Segovia"));
            clientes.add(new Cliente(121, "sda", "7526353Ñ", 82, "Aeas"));

            Set<Servicio> serviciosPorTipo  =   empresa.getServicios().stream().filter(x->x.getTipoDeServicio().equals(tipo)).collect(Collectors.toSet());
            List<Integer> ids =  serviciosPorTipo.stream().map(Servicio::getCodCliente).toList();
            //when
            when(empresa.getClientes()).thenReturn(clientes);
            when(empresa.getServicios()).thenReturn(servicios);
            Set<Cliente> list=daoEmpresaImpl.getListaClienteSegunSuTipoDeServicio(tipo);
            System.out.println(list.toString());
            //then
            assertAll(
                    ()->assertThat(list.stream().filter(x->ids.contains(x.getIdCliente())))
            );

        }
        @ParameterizedTest
        @CsvSource({"20,Corpo",
                "30,Cyber Delincuente",
                "40,Seguridad Ars"})
        void selectListaEmpleadoSegunEdadYPuesto(int edad, String puesto) {
            //given
            List<Instalaciones> inst=new ArrayList<>();
            inst.add(new Oficinas(1231,"Colombia"));
            inst.add(new Centrales(2131,"Almuñecar",12231));
            //when
            inst.get(0).getEmpleados().add(new Empleado("Edrian",1321,"9999999K",20,"Corpo",33123));
            inst.get(0).getEmpleados().add(new Empleado("Richard",1411,"9991999P",30,"Cyber Delincuente",33123));
            inst.get(0).getEmpleados().add(new Empleado("Handsome",131,"9999399D",40,"Seguridad Ars",33123));
            inst.get(0).getEmpleados().add(new Empleado("Len",121,"9999949G",20,"Corpo",33123));
            inst.get(0).getEmpleados().add(new Empleado("Joker",11,"9995999Q",30,"Cyber Delincuente",33123));
            inst.get(0).getEmpleados().add(new Empleado("Enian",321,"9989999Ñ",40,"Seguridad Ars",33123));
            inst.get(0).getEmpleados().add(new Empleado("Yon",999,"9990999N",30,"Cyber Delincuente",33123));

            //when
            when(empresa.getInstalaciones()).thenReturn(inst);
            Set<Empleado> listaEmp=daoEmpresaImpl.selectListaEmpleadoSegunEdadYPuesto(edad,puesto);
            System.out.println(listaEmp.toString());
            //then
            assertAll(
                    ()->assertThat(listaEmp.stream().filter(x->x.getEdad()==edad && x.getPuesto().equals(puesto)))
            );
        }
    }

}