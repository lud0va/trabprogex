package org.example.service;

import org.example.dao.DaoEmpresaImplementacion;
import org.junit.jupiter.api.Test;
import lombok.extern.log4j.Log4j2;
import org.example.domain.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@Log4j2
@ExtendWith(MockitoExtension.class)
class GestionEmpresaTest {
    @Mock
    DaoEmpresaImplementacion daoEmpresaImpl;
    @InjectMocks
    GestionEmpresa gestionEmpresa;
    @Test
    @BeforeEach
    void inicioCadaTest() {
        System.out.println("----Comienzo Test");
    }

    @AfterEach
    public void despuesCadaTest() {
        System.out.println("----Termina Test");
    }
    @Test
    void addClienteNull() {
       Cliente cliente=null;

        Set<Cliente> clientes = new HashSet<>();
        clientes.add(new Cliente(122, "Antonio", "1231234M", 22, "Murcia"));
        clientes.add(new Cliente(132, "pepe", "7296353H", 82, "Almuñecar"));
        //when
        when(daoEmpresaImpl.addCliente(cliente)).thenReturn(true);
        boolean flag=gestionEmpresa.addCliente(cliente);

        assertThat(flag).isEqualTo(true);








    }


    @Test
    void addEmpleado() {
        //given
        Empleado empleado=new Empleado("Abdul",321,"11231Ñ",23,"Limpia cristales",1500);
        List<Instalaciones> inst=new ArrayList<>();
        inst.add(new Oficinas(1231,"Cuba"));
        inst.add(new Centrales(2131,"Segovia",12231));
        //when
        when(daoEmpresaImpl.addEmpleado(empleado,1231)).thenReturn(true);
        boolean respuesta=  gestionEmpresa.addEmpleado(empleado,1231);
        //then
        assertThat(respuesta).isEqualTo(true);

    }



    @Test
    void empleadoMaxSalarioInstal() {
        //given
        List<Instalaciones> inst=new ArrayList<>();
        inst.add(new Oficinas(1231,"Colombia"));
        inst.add(new Centrales(2131,"Almuñecar",12231));
        //when
        inst.get(0).getEmpleados().add(new Empleado("Edrian",1321,"9999999K",20,"Corpo",33123));
        inst.get(0).getEmpleados().add(new Empleado("Richard",1411,"9991999P",30,"Cyber Delincuente",33123));
        inst.get(0).getEmpleados().add(new Empleado("Handsome",14412,"9999399D",40,"Seguridad Ars",33123123));
        inst.get(0).getEmpleados().add(new Empleado("Len",121,"9999949G",20,"Corpo",33123));
        inst.get(0).getEmpleados().add(new Empleado("Joker",11,"9995999Q",30,"Cyber Delincuente",33123));
        inst.get(0).getEmpleados().add(new Empleado("Enian",321,"9989999Ñ",40,"Seguridad Ars",33123));
        inst.get(0).getEmpleados().add(new Empleado("Yon",999,"9990999N",30,"Cyber Delincuente",33123));

        Set<Empleado> empleados=inst.get(0).getEmpleados();
        Empleado empleadox=Collections.max(empleados, Comparator.comparing(Empleado::getSalarioMens));
        //when
        when(daoEmpresaImpl.empleadoMaxSalarioInstal(1231)).thenReturn(empleadox);
        empleadox=daoEmpresaImpl.empleadoMaxSalarioInstal(1231);
        //then
        assertThat(empleadox).isEqualTo(Collections.max(empleados, Comparator.comparing(Empleado::getSalarioMens)));
    }


    @Test
    void getlistaDeInstPorLoc() {
        //given
        List<Instalaciones> list=new ArrayList<>();
        list.add(new Oficinas(3123,"Cordoba"));
        list.add(new Centrales(1312,"Almuñecar",333123));
        list.add(new Oficinas(1231,"Madrid"));
        list.add(new Oficinas(31343,"Cordoba"));
        list.add(new Centrales(1322,"Almuñecar",333123));
        list.add(new Oficinas(151,"Madrid"));

        List<Instalaciones> cord=new ArrayList<>();
        cord=list.stream().filter(x->x.getLoc().equals("Cordoba")).toList();
        //when
        when(daoEmpresaImpl.getlistaDeInstPorLoc("Cordoba")).thenReturn(cord);
        List<Instalaciones> locs=gestionEmpresa.getlistaDeInstPorLoc("Cordoba");
        //then
        assertThat(locs).isEqualTo(cord);
    }

    @Test
    void getListaClienteSegunSuTipoDeServicio() {
        //given
        Set<Servicio> servicios=new TreeSet<>();
        servicios.add(new Servicio(123,"Publico",113,111, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(153,"Privado",121,111, LocalDate.of((int) (Math.random() * 20) + 2000, (int) (Math.random() * 12) + 1, (int) (Math.random() * 28) + 1)));
        servicios.add(new Servicio(423,"Publico",113,111, LocalDate.of(((int) (Math.random() * 20) + 2000),( (int) (Math.random() * 12) + 1),( (int) (Math.random() * 28) + 1))));
        servicios.add(new Servicio(553,"Privado",121,111, LocalDate.of((int) (Math.random() * 20) + 2000, (int) (Math.random() * 12) + 1, (int) (Math.random() * 28) + 1)));
        Set<Cliente> clientes = new HashSet<>();
        clientes.add(new Cliente(113, "Antonio", "1231234M", 22, "Murcia"));
        clientes.add(new Cliente(121, "pepe", "7296353H", 82, "Almuñecar"));
        clientes.add(new Cliente(113, "fus", "126134P", 22, "Segovia"));
        clientes.add(new Cliente(121, "sda", "7526353Ñ", 82, "Aeas"));
        Set<Servicio> serviciosPorTipo  =  servicios.stream().filter(x->x.getTipoDeServicio().equals("Publico")).collect(Collectors.toSet());
        List<Integer> ids =  serviciosPorTipo.stream().map(Servicio::getCodCliente).toList();
        Set<Cliente> client=clientes.stream().filter(x->ids.contains(x.getIdCliente())).collect(Collectors.toSet());
        //when
        when(daoEmpresaImpl.getListaClienteSegunSuTipoDeServicio("Publico")).thenReturn(client);
        Set<Cliente> clientesFilter=gestionEmpresa.getListaClienteSegunSuTipoDeServicio("Publico");
        //then
        assertThat(clientesFilter).isEqualTo(client);
    }

    @Test
    void selectListaEmpleadoSegunEdadYPuesto() {

        //given
        List<Instalaciones> inst=new ArrayList<>();
        inst.add(new Oficinas(1231,"Colombia"));
        inst.add(new Centrales(2131,"Almuñecar",12231));
        //when
        inst.get(0).getEmpleados().add(new Empleado("Edrian",1321,"9999999K",20,"Corpo",33123));
        inst.get(0).getEmpleados().add(new Empleado("Richard",1411,"9991999P",30,"Cyber Delincuente",33123));
        inst.get(0).getEmpleados().add(new Empleado("Handsome",131,"9999399D",40,"Seguridad Ars",33123));
        inst.get(0).getEmpleados().add(new Empleado("Len",121,"9999949G",20,"Corpo",33123));
        inst.get(0).getEmpleados().add(new Empleado("Joker",11,"9995999Q",30,"Cyber Delincuente",33123));
        inst.get(0).getEmpleados().add(new Empleado("Enian",321,"9989999Ñ",40,"Seguridad Ars",33123));
        inst.get(0).getEmpleados().add(new Empleado("Yon",999,"9990999N",30,"Cyber Delincuente",33123));
        Set<Empleado> empleados=inst.get(0).getEmpleados().stream().filter(x->x.getPuesto().equals("Cyber Delincuente") && x.getEdad()==30).collect(Collectors.toSet());

        //when
        when(daoEmpresaImpl.selectListaEmpleadoSegunEdadYPuesto(30,"Cyber Delincuente")).thenReturn(empleados);
        Set<Empleado> emplEdPu=gestionEmpresa.selectListaEmpleadoSegunEdadYPuesto(30,"Cyber Delincuente");
        //then
        assertThat(emplEdPu).isEqualTo(empleados);

    }
}